using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item6 : ItemManager
{
    
    public int itCode = 6;
    public string itName = "지금은 잘 시간!";
    public string itDesc = "푹신한 베개잖아!\n한숨 자볼까...zz";

    public Item6()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
