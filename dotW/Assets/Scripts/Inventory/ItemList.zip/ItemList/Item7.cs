using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item7 : ItemManager
{
    
    public int itCode = 7;
    public string itName = "물구나무서기를 보여주지";
    public string itDesc = "보라색 사과는 무슨 맛일까??\n 와! 나 머리로 뛰어다녀!";

    public Item7()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
