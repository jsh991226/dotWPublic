using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item10 : ItemManager
{
    
    public int itCode = 10;
    public string itName = "여기가 어디야?";
    public string itDesc = "구름 속을 뛰어다니고 있어!\n앞은 안보이지만";

    public Item10()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
