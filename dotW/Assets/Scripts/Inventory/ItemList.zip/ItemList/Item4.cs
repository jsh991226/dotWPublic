using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item4 : ItemManager
{
    
    public int itCode = 4;
    public string itName = "다 덤벼!";
    public string itDesc = "뭐시기,,뭐시기뭐시기,,\n줄내	";

    public Item4()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }
    
    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
