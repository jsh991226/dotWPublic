using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item2 : ItemManager
{
    
    public int itCode = 2;
    public string itName = "바나나 껍질은 맛없어";
    public string itDesc = "그거 미끌미끌 하더라 \n 잘못하면 넘어지겠는걸";

    public Item2()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
