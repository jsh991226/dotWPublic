using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item5 : ItemManager
{
    
    public int itCode = 5;
    public string itName = "앞이 잘 안보여";
    public string itDesc = "나 안경 쓰니까 어때?\n근데 앞이 잘 안보이는거 같기도하구...";

    public Item5()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
