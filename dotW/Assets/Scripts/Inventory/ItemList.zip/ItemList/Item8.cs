using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item8 : ItemManager
{
    
    public int itCode = 8;
    public string itName = "나 어때?";
    public string itDesc = "내 피부색 마음에 안들어! \n 다른걸로 바꿀래";

    public Item8()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
