using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item9 : ItemManager
{
    
    public int itCode = 9;
    public string itName = "나는 안죽어!";
    public string itDesc = "봐봐! 아직 뛰어 다닐 수 있어!!";

    public Item9()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
