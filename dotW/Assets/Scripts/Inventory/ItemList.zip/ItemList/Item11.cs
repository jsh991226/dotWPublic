using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item11 : ItemManager
{
    
    public int itCode = 11;
    public string itName = "나 데리고 가";
    public string itDesc = "너 좀 마음에 든다! \n나랑 같이 갈래?";

    public Item11()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
