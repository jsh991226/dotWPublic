using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item3 : ItemManager
{
    
    public int itCode = 3;
    public string itName = "밥 먹는 손은 왼손?";
    public string itDesc = "나는 오른손 잡이인데 \n 어디가 오른손이지";

    public Item3()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");
    }


}
