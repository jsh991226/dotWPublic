using System.Collections;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

public class Item1 : ItemManager
{
    
    public int itCode = 1;
    public string itName = "동글동글 문어";
    public string itDesc = "내가 좋아하는 문어야 \n 먹물을 가지고 있으니까 조심해!";

    public Item1()
    {
        base.itemCode = itCode;
        base.itemName = itName;
        base.itemDesc = itDesc;
    }

    public override void itemUse(GameObject usePlayer)
    {
        Debug.Log("Using Item [ player : " + usePlayer.GetComponent<PhotonView>().Owner.NickName + " ]");


    }


}
